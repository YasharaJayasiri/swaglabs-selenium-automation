package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Assignment {

    //Global variable section

    String BaseURL="https://www.saucedemo.com/";
    WebDriver driver;
    String ActualPgHeading,ActualHeading1,ActualHeading2,ActualHeading3,ActualInfo,ActualText1,ActualText2,ActualText3,ActualQty,ActualPrice,ActualItemTotal;
    String  ExpectedPgHeading, ExpectedHeading1, ExpectedHeading2, ExpectedHeading3, ExpectedInfo, ExpectedText1, ExpectedText2, ExpectedText3, ExpectedQty,ExpectedPrice,ExpectedItemTotal;
    Boolean Status;


    //Before test section

    @BeforeTest
    public void BeforeTestMethod(){
        driver=new ChromeDriver();
        driver.manage().window().maximize();
    }


    //Test case section

    //Test case-Happy path-Tc 01
    @Test(priority = 1)
    public void HappyPath() throws InterruptedException {
        System.out.println("..................Tc 01 Start..................");
        //Login to the system
        UserLogin();
        //click the add to cart button
        ProductPgAddToCartBtnClick();
        //click te cart badge
        ProductPgCartBadgeClick();
        //click your cart page checkout button
        YourCartPgCheckoutBtnClick();
        //Identify the first name and send value
        driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys("Nike");
        //Identify the last name and send value
        driver.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys("Fernando");
        //Identify the postal code  and send value
        driver.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys("10300");
        //click your information page continue button
        YourInfoPgContinueBtnClick();
        // click the overview page finish button
        OverviewPgFinishBtnClick();
        //click the complete page back home button
        CompletePgBackHomeBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        ExpectedPgHeading="Products";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation of Happy Path");
        }
        else {
            System.out.println("Unsuccessful validation of Happy Path");
        }
        System.out.println("..................Tc 01 End...................");
    }

    //Test case-Entering only username when login-Tc 02
    @Test(priority = 2)
    public void LoginOnlyWithUserName() throws InterruptedException {
        System.out.println("..................Tc 02 Start...................");
        //click the side menu
        SideMenu();
        //click the logout option on side menu
        Logout();
        //Identify the username text box and send value
        driver.findElement(By.name("user-name")).sendKeys("standard_user");
        //click the login button
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        Thread.sleep(3000);
        ExpectedPgHeading="Epic sadface: Password is required";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation on (Negative Tc 01 )");
        }
        else {
            System.out.println("Unsuccessful validation on  (Negative Tc  01)");
        }
        System.out.println("..................Tc 02  End...................");
    }


    //Test case-Login with invalid password and valid username-Tc 03
    @Test(priority = 3)
    public void LoginWithInvalidPassword() throws InterruptedException {
        System.out.println("..................Tc 03 Start...................");
        //Identify the  password text box and send value
        driver.findElement(By.name("password")).sendKeys(" car");
        //Identify the  login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        Thread.sleep(3000);
        ExpectedText1="Epic sadface: Username and password do not match any user in this service";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
        if ( ExpectedText1.equals(ActualText1 )){
            System.out.println("Successful validation on (Negative Tc  02)");
        }
        else {
            System.out.println("Unsuccessful validation on (Negative Tc  02) ");
        }
        System.out.println("..................Tc 03  End...................");
    }


    //Test case-Entering only  password when login-Tc 04
    @Test(priority = 4)
    public void  LoginOnlyWithPassword() throws InterruptedException {
        System.out.println("..................Tc 04 Start...................");
        //do the user login
        UserLogin();
        //choose the side menu
        SideMenu();
        //do the logout
        Logout();
        //Identify the  password text box and send value
        driver.findElement(By.xpath(" //*[@id=\"password\"]")).sendKeys(" secret_sauce");
        //Identify the  login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        Thread.sleep(3000);
        ExpectedText2=" Epic sadface: Username is required ";
        ActualText2=driver.findElement(By.xpath(" //*[@id=\"login_button_container\"]/div/form/div[3]/h3  ")).getText();
        if ( ExpectedText2.equals(ActualText2 )){
            System.out.println("Successful validation on( Negative Tc  03)");
        }
        else {
            System.out.println("Successful validation on (Negative Tc  03) ");
        }
        System.out.println("..................Tc 04 End...................");
    }



    //Test case-Entering invalid user name and valid password-Tc 05
    @Test(priority = 5)
    public void LoginWithInvalidUserName() throws InterruptedException {
        System.out.println("..................Tc 05 Start...................");
        //Identify the Username text box and send value
        driver.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys(" red");
        //Identify the login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        //Wait for 2 seconds
        Thread.sleep(2000);
        ExpectedText1="Epic sadface: Username and password do not match any user in this service";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
        if (ExpectedText1.equals(ActualText1)){
            System.out.println("Successful validation on (Negative Tc  04)");
        }
        else {
            System.out.println("Unsuccessful validation on (Negative Tc  04)");
        }
        System.out.println("..................Tc 05 End...................");
    }



    //Test case-Entering invalid username and invalid password-Tc 06
    @Test(priority = 6)
    public void LoginWithInvalidUserNameInvalidPassword(){
        System.out.println("..................Tc 06 Start...................");
        //Identify the  password text box and send value
        driver.findElement(By.xpath(" //*[@id=\"password\"]")).sendKeys("car");
        //Identify the login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        ExpectedText1="Epic sadface: Username and password do not match any user in this service";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
        if (ExpectedText1.equals(ActualText1)){
            System.out.println("Successful validation on (Negative Tc  05)");
        }
        else {
            System.out.println("Unsuccessful validation on (Negative Tc  05)");
        }
        System.out.println("..................Tc 06 End...................");

    }



    //Test case-Product page loading validation-Tc 07
    @Test(priority = 7)
    public void ProductPgLoadingValidation() throws InterruptedException {
        System.out.println("..................Tc 07 Start...................");

        //do the user login
        UserLogin();
        //choose the side menu
        SideMenu();
        //do the logout
        Logout();
        //Identify the username text box and send value
        driver.findElement(By.name("user-name")).sendKeys("standard_user");
        //Identify the  password text box and send value
        driver.findElement(By.name("password")).sendKeys("secret_sauce");
        //Identify the  login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        Thread.sleep(3000);

        ExpectedPgHeading="Products";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation of Products page loading ");
        }
        else {
            System.out.println("Unsuccessful validation of Products page loading");
        }
        System.out.println("..................Tc 07  End...................");
    }



    //Test case-Product page information validation-Tc 08
    @Test(priority =8)
    public void ProductPgInfoValidation(){
        System.out.println("..................Tc 08 Start...................");
        ExpectedHeading1="Sauce Labs Backpack";
        ActualHeading1=driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
        ExpectedInfo="carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
        ActualInfo=driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[1]/div")).getText();
        ExpectedPrice="$29.99";
        ActualPrice=driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[2]/div")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)&&ExpectedInfo.equals(ActualInfo)&&ExpectedPrice.equals(ActualPrice)){
            System.out.println("Successful validation of Products page  information ");
        }
        else {
            System.out.println("Unsuccessful validation of Products page information  ");
        }
        System.out.println("..................Tc 08 End...................");
    }



    //Test case-Checking' Add to cart' button become as 'remove' when clicked-Tc 09
    @Test(priority = 9)
    public void AddToCartToRemoveBtnValidation() throws InterruptedException {
        System.out.println("..................Tc 09 Start...................");
        //click the ' add to cart' button
        ProductPgAddToCartBtnClick();
        ExpectedHeading1="Remove";
        ActualHeading1=driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-backpack\"]")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Successful validation on Add to cart button ");
        }
        else {
            System.out.println("Unsuccessful validation on Add to cart button ");
        }
        System.out.println("..................Tc 09 End...................");
    }



    // Test case-Checking 'remove' button become as ' add to cart' when clicked-Tc 10
    @Test(priority =10 )
    public void RemoveBtnToAddToCartValidation() throws InterruptedException {
        System.out.println("..................Tc 10 Start...................");
        //click the 'remove' button
         ProductPgRemoveBtnClick();
        ExpectedHeading1="Add to cart";
        ActualHeading1=driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Successful validation on Remove button ");
        }
        else {
            System.out.println("Unsuccessful validation on Remove button ");
        }
        System.out.println("..................Tc 10 End...................");
    }



    //Test case-Your cart page loading validation-Tc 11
    @Test(priority =11 )
    public void YourCartPgLoadingValidation() throws InterruptedException {
        System.out.println("..................Tc 11 Start...................");
        //click the 'Add to cart' button
        ProductPgAddToCartBtnClick();
        //click the 'cart badge ' icon
        ProductPgCartBadgeClick();
        ExpectedPgHeading="Your Cart";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation on 'your cart' page loading ");
        }
        else {
            System.out.println("Unsuccessful validation on 'your cart 'page loading ");
        }
        System.out.println("..................Tc 11 End...................");
    }




    //Test case-Your cart page information validation-Tc 12
    @Test(priority = 12)
    public void YourCartPgInformationValidation(){
        System.out.println("..................Tc 12 Start...................");
        ExpectedQty="1";
        ActualQty=driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[1] ")).getText();
        ExpectedHeading1="Sauce Labs Backpack";
        ActualHeading1=driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
        ExpectedInfo="carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
        ActualInfo=driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[1]")).getText();
        ExpectedItemTotal="$29.99";
        ActualItemTotal=driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div")).getText();
        if (ExpectedQty.equals(ActualQty)&&ExpectedHeading1.equals(ActualHeading1)&&ExpectedInfo.equals(ActualInfo)&&ExpectedItemTotal.equals(ActualItemTotal)){
            System.out.println("Successful validation on page information'your cart' ");
        }
        else {
            System.out.println("Unsuccessful validation on 'your cart 'page information  ");
        }
        System.out.println("..................Tc 12 End...................");
    }



    //Test case-Your cart page 'Continue shopping' button validation-Tc 13
    @Test(priority = 13)
    public void YourCartPgContinueShoppingBtnValidation() throws InterruptedException {
        System.out.println("..................Tc 13 Start...................");
        //click the 'Continue shopping ' button
        YourCartPgContinueShoppingBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        ExpectedPgHeading="Products";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation on 'Continue shopping ' button");
        }
       else{
            System.out.println("Unsuccessful validation on 'Continue shopping ' button   ");
        }
        System.out.println("..................Tc 13 End...................");

    }



    //Test case-Your cart page ' Remove ' button validation-Tc 14
    @Test(priority =14 )
    public void YourCartPgRemoveBtnValidation() throws InterruptedException {
        System.out.println("..................Tc 14 Start...................");
        //click the cart badge
        ProductPgCartBadgeClick();
        //click the 'Remove' button
        ProductPgRemoveBtnClick();
        //wait for 2 seconds till the page load
        Thread.sleep(2000);
        //verify if only 'Continue shopping' and 'Checkout' buttons are  visible
        WebElement ContinueShoppingBtn=driver.findElement(By.xpath(" //*[@id=\"continue-shopping\"]"));
        WebElement  CheckoutButton=driver.findElement(By.xpath("//*[@id=\"checkout\"]"));

        if (ContinueShoppingBtn.isDisplayed()&&CheckoutButton.isDisplayed()) {
        System.out.println("  Successful validation on 'Remove' button(continue and checkout buttons were visible successfully)");
        }
        else {
        System.out.println("  Unsuccessful validation on 'Remove' button(continue and checkout buttons were visible successfully)");

        }
        System.out.println(" ................Tc 14 End ................... ");
    }




   //Test case-Your cart page 'Checkout' button validation-Tc 15
    @Test(priority = 15)
    public void YourCartPgCheckoutBtnValidation() throws InterruptedException {
        System.out.println("..................Tc 15 Start...................");
        //click the continue shopping button
        YourCartPgContinueShoppingBtnClick();
        //click the 'Add to cart' button
        ProductPgAddToCartBtnClick();
        //click the cart badge  button
        ProductPgCartBadgeClick();
        //click the checkout button
        YourCartPgCheckoutBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        ExpectedPgHeading="Checkout: Your Information";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation on 'Checkout ' button");
        }
        else {
            System.out.println("Unsuccessful validation on 'Checkout ' button");
        }
        System.out.println("..................Tc 15  End...................");
    }

    //Test case-'Your information page' validation-Tc 16
    @Test(priority =16 )
    public void YourInformationPgLoadingValidation(){
        System.out.println("..................Tc 16 Start...................");
        ExpectedHeading1="Checkout: Your Information";
        ActualHeading1=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if(ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Successful validation on ' Your Information ' page loading  ");
        }
        else {
            System.out.println("Unsuccessful validation on ' Your Information ' page loading ");
        }
        System.out.println("..................Tc 16  End...................");
    }

    // Negative Test case-Entering only 'First Name'-Tc 17
    @Test(priority = 17)
    public void EnteringOnlyFirstName() throws InterruptedException {
        System.out.println("..................Tc 17 (Negative Tc 06) Start...................");
        //sending only the first name
        //identify the first name text box and send value
        driver.findElement(By.name("firstName")).sendKeys("Nike");
        //click the continue button
        YourInfoPgContinueBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        ExpectedText1="Error: Last Name is required";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Expected error message is displayed successfully");
        }
        else {
            System.out.println("Expected error message is not displayed ");

        }
        System.out.println("..................Tc 17 (Negative Tc 06)End...................");

    }



    // Negative Test case-Entering only ' Last Name'-Tc 18
    @Test(priority =18)
    public void EnteringOnlyFLastName() throws InterruptedException {
        System.out.println("..................Tc 18 (Negative Tc 07) Start...................");
        //click the cancel button
        YourInfoPgCancelBtnClick();
        //click the checkout button
        YourCartPgCheckoutBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        //identify the  Last name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"last-name\"] ")).sendKeys(" Fernando");
        //click the continue button
        YourInfoPgContinueBtnClick();
        ExpectedText1="Error: First Name is required";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Expected error message is displayed successfully");
        }
        else {
            System.out.println("Expected error message is not displayed ");

        }
        System.out.println("..................Tc 18 (Negative Tc 07)End...................");
    }



    // Negative Test case-Entering only 'Postal code'-Tc 19
    @Test(priority = 19)
    public void EnteringOnlyPostalCode() throws InterruptedException {
        System.out.println("..................Tc 19(Negative Tc 08) Start...................");
        //click the cancel button
        YourInfoPgCancelBtnClick();
        //click the checkout button
        YourCartPgCheckoutBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        //identify the  Last name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"postal-code\"]")).sendKeys(" 10300");
        //click the continue button
        YourInfoPgContinueBtnClick();
        ExpectedText1=" Error: First Name is required";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Expected error message is displayed successfully");
        }
        else {
            System.out.println("Expected error message is not displayed ");

        }
        System.out.println("..................Tc 19 (Negative Tc 08)End...................");
    }

    //Negative Test case-Entering only first name and last name-Tc 20
    @Test(priority =20 )
    public void EnteringOnlyFirstNameNLastName() throws InterruptedException {
        System.out.println("..................Tc 20 (Negative Tc 09) Start...................");
        //click the cancel button
        YourInfoPgCancelBtnClick();
        //click the checkout button
        YourCartPgCheckoutBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        //identify the first name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"first-name\"] ") ).sendKeys(" Nike ");
        //identify the  Last name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"last-name\"] ")).sendKeys(" Fernando");
        //click the continue button
        YourInfoPgContinueBtnClick();
        ExpectedText1="Error: Postal Code is required ";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3 ")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Expected error message is displayed successfully");
        }
        else {
            System.out.println("Expected error message is not displayed ");

        }
        System.out.println("..................Tc 20 (Negative Tc 09)End...................");
    }

    //Negative Test case-Entering only first name and postal code-Tc 21
    @Test(priority =21 )
    public void EnteringOnlyFirstNameNPostalCode() throws InterruptedException {
        System.out.println("..................Tc 21(Negative Tc 10) Start...................");
        //click the cancel button
        YourInfoPgCancelBtnClick();
        //click the checkout button
        YourCartPgCheckoutBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
        //identify the first name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"first-name\"] ") ).sendKeys(" Nike ");
        //identify the postal code  text box and send value
        driver.findElement(By.xpath(" //*[@id=\"postal-code\"] ")).sendKeys("10300  ");
        //click the continue button
        YourInfoPgContinueBtnClick();
        ExpectedText1=" Error: Last Name is required";
        ActualText1=driver.findElement(By.xpath(" //*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Expected error message is displayed successfully");
        }
        else {
            System.out.println("Expected error message is not displayed ");

        }
        System.out.println("..................Tc 21 (Negative Tc 10)End...................");
    }

    //Negative Test case-Entering only  last name and postal code-Tc 22
    @Test(priority =22 )
    public void EnteringOnlyLastNameNPostalCode() throws InterruptedException {
        System.out.println("..................Tc 22(Negative Tc 11) Start...................");
        //click the cancel button
        YourInfoPgCancelBtnClick();
        //click the checkout button
        YourCartPgCheckoutBtnClick();

        //identify the last name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"last-name\"]  ") ).sendKeys(" Fernando  ");
        //identify the postal code  text box and send value
        driver.findElement(By.xpath(" //*[@id=\"postal-code\"] ")).sendKeys("10300  ");
        //click the continue button
        YourInfoPgContinueBtnClick();
        ExpectedText1=" Error: First Name is required";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3 ")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)){
            System.out.println("Expected error message is displayed successfully");
        }
        else {
            System.out.println("Expected error message is not displayed ");

        }
        System.out.println("..................Tc 22(Negative Tc 11)End...................");
    }


    // Testcase- Your information page loading validation-Tc 23
    @Test(priority =23)
    public void YourInformationPgContinueButtonValidation() throws InterruptedException {
        System.out.println("..................Tc 23 Start...................");

        //identify the first name text box and send value
        driver.findElement(By.xpath(" //*[@id=\"first-name\"] ") ).sendKeys(" Nike ");

        //click the continue button
        YourInfoPgContinueBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);
         ExpectedPgHeading="Checkout: Overview ";
         ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if ( ExpectedPgHeading.equals( ActualPgHeading)){
            System.out.println("Successful validation on 'Continue' button");
        }
        else {
            System.out.println(" Successful validation on 'Continue' button");

        }
        System.out.println("..................Tc 23 End...................");
    }

    // Testcase-  Overview page loading validation-Tc 24
    @Test(priority = 24)
    public void OverviewPgLoadingValidation(){
        System.out.println("..................Tc  24 Start...................");
        ExpectedPgHeading="Checkout: Overview";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful Overview page validation");
        }
        else {
            System.out.println("Unsuccessful Overview page validation");
        }
        System.out.println("..................Tc  24 End...................");
    }


    // Testcase-  Overview page information validation-Tc 25
    @Test(priority =25 )
    public void OverviewPgInformationValidation() {
        System.out.println("..................Tc 25 Start...................");
        ExpectedQty = "1";
        ActualQty = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[1]")).getText();
        ExpectedHeading1 = "Sauce Labs Backpack";
        ActualHeading1 = driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
        ExpectedInfo = "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
        ActualInfo = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[2]/div[1]")).getText();
        ExpectedPrice = "$29.99";
        ExpectedPrice=ExpectedItemTotal ;

        ActualPrice = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[2]/div[2]/div")).getText();

        if (ExpectedQty.equals(ActualQty) && ExpectedHeading1.equals(ActualHeading1) && ExpectedInfo.equals(ActualInfo) && ExpectedPrice.equals(ActualPrice)) {
            System.out.println("Successful Overview page information validation");
        } else {
            System.out.println("Unsuccessful Overview page information validation");
        }
        System.out.println("..................Tc 25 End...................");
    }


    // Testcase-  Overview page payment information validation-Tc 26
    @Test(priority = 26)
    public void OverviewPgPaymentInformationValidation(){
        System.out.println("..................Tc 26 Start...................");
        ExpectedHeading1="Payment Information:";
        ActualHeading1 = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[1] ")).getText();
        ExpectedText1="SauceCard #31337";
        ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[2]")).getText();
        ExpectedHeading2="Shipping Information:";
        ActualHeading2 = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[3]")).getText();
        ExpectedText2="Free Pony Express Delivery!";
        ActualText2=driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[4]")).getText();
        ExpectedHeading3="Price Total";
        ActualHeading3 = driver.findElement(By.xpath(" //*[@id=\"checkout_summary_container\"]/div/div[2]/div[5]")).getText();
        if (ExpectedHeading1.equals(ActualHeading1)&&ExpectedText1.equals(ActualText1)&&ExpectedHeading2.equals(ActualHeading2)&&ExpectedText2.equals(ActualText2)&&ExpectedHeading3.equals(ActualHeading3)){
            System.out.println("Successful Overview page Payment information validation");
        }
        else{
            System.out.println("Unsuccessful Overview page Payment information validation");
        }
        System.out.println("..................Tc 26 End...................");
    }

    // Testcase-  Overview page total calculation validation-Tc 27
    @Test(priority = 27)
    public void OverviewPgTotalCalculationValidation(){
        System.out.println("..................Tc 27 Start...................");
        double ItemTotal=29.9,Total;
        double Tax=2.40;
        Total=ItemTotal+Tax;


        ExpectedText1="Item total: $ "+ ItemTotal;
        ActualText1=driver.findElement(By.xpath(" //*[@id=\"checkout_summary_container\"]/div/div[2]/div[6]")).getText();
        ExpectedText2="Tax: $"+Tax;
        ActualText2=driver.findElement(By.xpath(" //*[@id=\"checkout_summary_container\"]/div/div[2]/div[7]")).getText();
        ExpectedText3="Total: $"+Total;
        ActualText3=driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[8] ")).getText();
        if (ExpectedText2.equals(ActualText2)&&ExpectedText1.equals(ActualText1)&&ExpectedText3.equals(ActualText3)){
            System.out.println("Successful Overview page Total calculation validation");
        }
        else {
            System.out.println("Unsuccessful Overview page Total calculation validation");
        }
        System.out.println("..................Tc 27 End...................");
    }


    //Test case-Overview page 'Finish' button validation-Tc 28
    @Test(priority = 28)
     public void OverviewPgFinishButtonValidation() throws InterruptedException {
        System.out.println("..................Tc 28 Start...................");
     //Identify the Finish button and click
        OverviewPgFinishBtnClick();
        //wait for 2 seconds
        Thread.sleep(2000);

      ExpectedText1 ="Checkout: Complete!";
      ActualText1=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
     if ( ExpectedText1.equals( ActualText1)){
        System.out.println("Successful validation on Finish button ");
     }
     else {
         System.out.println("Unsuccessful validation on Finish button ");
     }
        System.out.println("..................Tc 28 End...................");

    }


    //Test case- 'Complete' page loading validation-Tc 29
    @Test(priority = 29)
    public void CompletePgLoadingValidation(){
        System.out.println("..................Tc 29 Start...................");
        ExpectedPgHeading="Checkout: Complete!";
        ActualPgHeading=driver.findElement(By.xpath(" //*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation on Complete page loading ");
        }
        else {
            System.out.println("Unsuccessful validation on Complete page loading ");
        }
        System.out.println("..................Tc 29 End...................");
    }


    //Test case- 'Complete' page  information validation-Tc 30
    @Test(priority = 30)
    public void CompletePgInfoValidation(){
        System.out.println("..................Tc 30 Start...................");

         ExpectedText1="Thank you for your order!";
         ActualText1=driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")).getText();
         ExpectedText2 ="Your order has been dispatched, and will arrive just as fast as the pony can get there!";
         ActualText2 =driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/div")).getText();

        if (ExpectedText1.equals(ActualText1)&&ExpectedText2.equals(ActualText2)){
            System.out.println("Successful validation on Complete page information loading ");
        }
        else {
            System.out.println("Unsuccessful validation on Complete page information loading ");
        }

        System.out.println("..................Tc 30 End...................");
    }


    //Test case-Complete page 'Back Home' button validation-Tc 31
    @Test(priority = 31)
    public void CompletePgBackHomeButtonValidation() throws InterruptedException {
        System.out.println("..................Tc 31 Start...................");
        CompletePgBackHomeBtnClick();

        ExpectedPgHeading="Products";
        ActualPgHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (ExpectedPgHeading.equals(ActualPgHeading)){
            System.out.println("Successful validation on Complete page  Back Home button ");
        }
        else {
            System.out.println("Unsuccessful validation on Complete page  Back Home button ");
        }
        System.out.println("..................Tc 31 End...................");

    }




    //After Test Section

    @AfterTest
    public void AfterTestMethod() throws InterruptedException {
        Thread.sleep(5000);
        driver.quit();
    }






    //Supportive method section

    public void UserLogin() throws InterruptedException {
        //calling the SwagLabs login page
        driver.get(BaseURL);
        Thread.sleep(3000);
        //Identify the username text box and send value
        driver.findElement(By.name("user-name")).sendKeys("standard_user");
        //Identify the  password text box and send value
        driver.findElement(By.name("password")).sendKeys("secret_sauce");
        //Identify the  login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        Thread.sleep(3000);

    }

    public void ProductPgAddToCartBtnClick() throws InterruptedException {
        //click the product page add to cart button
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void ProductPgRemoveBtnClick() throws InterruptedException {
        //click the product page remove button
        driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void ProductPgCartBadgeClick() throws InterruptedException {
        //click the product page cart badge
        driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void  YourCartPgContinueShoppingBtnClick() throws InterruptedException {
        //click your cart page continue shopping button
        driver.findElement(By.xpath(" //*[@id=\"continue-shopping\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void  YourCartPgCheckoutBtnClick() throws InterruptedException {
        //click your cart page checkout button
        driver.findElement(By.xpath(" //*[@id=\"checkout\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void  YourCartPgRemoveBtnClick() throws InterruptedException {
        //click your cart page remove button
        driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void   YourInfoPgContinueBtnClick() throws InterruptedException {
        //click your information page continue button
        driver.findElement(By.xpath(" //*[@id=\"continue\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void   YourInfoPgCancelBtnClick() throws InterruptedException {
        //click your information page cancel button
        driver.findElement(By.xpath(" //*[@id=\"cancel\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }




    public void OverviewPgFinishBtnClick() throws InterruptedException {
        //click your overview page finish button
        driver.findElement(By.xpath("//*[@id=\"finish\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void CompletePgBackHomeBtnClick() throws InterruptedException {
        //click your complete page back home button
        driver.findElement(By.xpath(" //*[@id=\"back-to-products\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void SideMenu() throws InterruptedException {
        //click side menu
        driver.findElement(By.xpath("//*[@id=\"react-burger-menu-btn\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }

    public void Logout() throws InterruptedException {
        //click logout
        driver.findElement(By.xpath("//*[@id=\"logout_sidebar_link\"]")).click();
        //wait for 3 seconds
        Thread.sleep(3000);
    }






















}
