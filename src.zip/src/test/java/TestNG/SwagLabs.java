package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SwagLabs {
    //Global variable section
    String BaseURL = "https://www.saucedemo.com/";
    WebDriver driver;
    String actualText, actualHeading, actualInfo, actualPrice, actualQty,actualItemTotal;
    String expectedText, expectedHeading, expectedInfo, expectedPrice, expectedQty,expectedItemTotal;
    Boolean status;

    //Before test section
    @BeforeTest
    public void BeforeTestMethod() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }



    //Test case section
    //Test case-Validating the "Your cart" page loading -Tc 01
    @Test(priority = 1)
    public void VerifyYourCartPageLoading() throws InterruptedException {
        System.out.println("................Tc 01 Start...................");
        // Calling SwagLabs login page
        UserLogin();
        //Click the 'Add to cart' button on the Products page
        AddToCartBtn();
        //wait 2 seconds
        Thread.sleep(2000);
        //Click the cart badge  on the Products page
        CartBadgeClick();
        //wait 2 seconds
        Thread.sleep(2000);
        //verify if the 'Your Cart' page loaded
        expectedHeading = "Your Cart";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();

        if (expectedHeading.equals(actualHeading)) {
            System.out.println("Successful validation on 'Your Cart' page loading  ");
        } else {
            System.out.println("Unsuccessful validation on 'Your Cart' page loading  ");
        }
        System.out.println("................Tc 01  End..................");
    }




    //Test case-Validating the "Your cart" page information -Tc 02
    @Test(priority = 2)
    public void VerifyYourCartPageInfo() throws InterruptedException {
        System.out.println("................Tc 02 Start...................");


        expectedQty="1";
        actualQty=driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[1]")).getText();
        expectedHeading="Sauce Labs Backpack";
        actualHeading=driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
        expectedInfo="carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
        actualInfo=driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[1]")).getText();
        expectedPrice="$29.99";
        actualPrice=driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div")).getText();

        if (expectedQty.equals(actualQty)&&expectedHeading.equals(actualHeading)&&expectedInfo.equals(actualInfo)&&expectedPrice.equals(actualPrice)) {
            System.out.println("Successful validation on 'Your Cart' page information ");
        }
        else {
            System.out.println("Unsuccessful validation on 'Your Cart' page information ");
        }
        System.out.println("................Tc 02  End...................");

    }





    //Test case -verification of the Continue Shopping Button-Tc 03
    @Test(priority = 3)
    public void VerifyContinueShoppingButton() throws InterruptedException {
        System.out.println("................Tc 03 Start...................");

        //click the Continue Shopping button
        YourCartContinueShoppingBtnClick();
        //wait for 2 seconds till the page loads
        Thread.sleep(2000);
        //verify if the 'Products' page loads
        expectedHeading="Products";
        actualHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();

        if (expectedHeading.equals(actualHeading)){
            System.out.println("Successful validation on 'Products page' loading");
        }
        else {
            System.out.println("Unsuccessful validation on 'Products page' loading ");
        }
        System.out.println("...............Tc 03  End...................");

    }



    //Test case -verification of the 'Checkout' Button-Tc 04
    @Test(priority = 4)
    public void VerifyCheckoutButton() throws InterruptedException {
    System.out.println("................Tc 04 Start................... ");


        //Click the 'remove ' button on the Products page
         RemoveBtn();
        //wait 2 seconds
        Thread.sleep(2000);
        //Click the 'Add to cart' button on the Products page
         AddToCartBtn();
        //wait 2 seconds
        Thread.sleep(2000);
        //Click the cart badge  on the Products page
        CartBadgeClick();
        Thread.sleep(3000);

        //click the checkout button
    YourCartCheckoutBtnClick();

    //verify if the 'Products' page loads
    expectedHeading="Checkout: Your Information";
    actualHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();

    if (expectedHeading.equals(actualHeading)) {
        System.out.println("Successful validation on 'Your Information' page loading");
    }
    else {
        System.out.println("Unsuccessful validation on 'Your Information' page loading ");
    }
    System.out.println(" ...............Tc 04 End...................");

    }


    //Test case -Validation of remove button -Tc 05
    @Test(priority = 5)
    public void VerifyRemoveButton() throws InterruptedException {
        System.out.println("................Tc 05 Start...................  ");

        //click the cancel button
        driver.findElement(By.xpath("//*[@id=\"cancel\"]")).click();
        //wait 2 seconds
        Thread.sleep(2000);

        //click the remove button
        YourCartRemoveBtnClick();
        //wait for 2 seconds till the page loads
        Thread.sleep(2000);
        //verify if only 'Continue shopping' and 'Checkout' button visible
        WebElement ContinueShoppingBtn=driver.findElement(By.xpath(" //*[@id=\"continue-shopping\"]"));
        WebElement  CheckoutButton=driver.findElement(By.xpath("//*[@id=\"checkout\"]"));

        if (ContinueShoppingBtn.isDisplayed()&&CheckoutButton.isDisplayed()) {
            System.out.println("Button visibility is successful");
        }
        else {
            System.out.println("Button visibility is unsuccessful");

        }
        System.out.println(" ................Tc 05 End ................... ");
    }










    //After Test Section
    @AfterTest
    public void AfterTestMethod() throws InterruptedException {
        Thread.sleep(5000);
        driver.quit();
    }





    //Supportive method section
    public void UserLogin() throws InterruptedException {
        //calling the SwagLabs login page
        driver.get(BaseURL);
        Thread.sleep(3000);
        //Identify the username text box and send value
        driver.findElement(By.name("user-name")).sendKeys("standard_user");
        //Identify the  password text box and send value
        driver.findElement(By.name("password")).sendKeys("secret_sauce");
        //Identify the login button and click
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        Thread.sleep(3000);
    }

    public void AddToCartBtn() throws InterruptedException {
        //click the add to cart button
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
    }

    public void  RemoveBtn() throws InterruptedException {
        //click the remove button
        driver.findElement(By.xpath("//*[@id=\"remove-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
    }


    public void YourCartRemoveBtnClick() throws InterruptedException {
        //click the  cart page remove button
        driver.findElement(By.xpath("//*[@id=\"remove-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
    }

    public void YourCartCheckoutBtnClick() throws InterruptedException {
        //click the  cart page checkout page
        driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
    }

    public void YourCartContinueShoppingBtnClick() throws InterruptedException {
        //click the cart page continue shopping button
        driver.findElement(By.xpath("//*[@id=\"continue-shopping\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
    }

    public void CartBadgeClick() throws InterruptedException {
        //click the cart in the products page
        driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
    }

    public void ProductsPage() throws InterruptedException {
        //click the login button
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
        //verify if the products page loading-Tc 06
        expectedHeading = "Products";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (expectedHeading.equals(actualHeading)) {
            System.out.println("Successful click on Products page");
        } else {
            System.out.println(("Unsuccessful click on Products page "));
        }
        //verify the information cards on Products page -Tc 07
        //verify the card one
        System.out.println(".......Card one verification start.......");
        expectedHeading = "Sauce Labs Backpack";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
        expectedInfo = "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[1]/div")).getText();
        expectedPrice = "$29.99";
        actualPrice = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[2]/div")).getText();
        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("Card one information is complete  ");
        } else {
            System.out.println("Card one information is not completed");
        }

        //verify if the' Add to cart button' becomes as 'remove' when clicked-Tc 08
        //click the Add to cart button
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = "Remove";
        actualText = driver.findElement(By.xpath("//*[@id=\"remove-sauce-labs-backpack\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("'Add to cart' changed as 'remove' ");
        } else {
            System.out.println("'Add to cart' became as 'remove' failed ");
        }

        //verify if the 'remove' button becomes as 'Add to cart'  when clicked-Tc 09
        //click the 'remove' button
        driver.findElement(By.xpath("//*[@id=\"remove-sauce-labs-backpack\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Add to cart";
        actualText = driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println(" 'Remove' changed as 'Add to cart' ");
        } else {
            System.out.println("  'Remove' changed as 'Add to cart' failed  ");
        }
        System.out.println("......Card one verification End......");

        //verify the card two
        System.out.println(".......Card two verification start.......");
        expectedHeading = "Sauce Labs Bike Light";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"item_0_title_link\"]/div")).getText();
        expectedInfo = "A red light isn't the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included.";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[2]/div[2]/div[1]/div")).getText();
        expectedPrice = "$9.99 ";
        actualPrice = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[2]/div[2]/div[2]/div")).getText();
        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("Card two information is complete  ");
        } else {
            System.out.println("Card two information is not completed");
        }

        //verify if the' Add to cart button' becomes as 'remove' when clicked
        //click the Add to cart button
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-bike-light\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Remove";
        actualText = driver.findElement(By.xpath("//*[@id=\"remove-sauce-labs-bike-light\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("'Add to cart' changed as 'remove' ");
        } else {
            System.out.println("'Add to cart' became as 'remove' failed ");
        }

        //verify if the 'remove' button becomes as 'Add to cart'  when clicked
        //click the 'remove' button
        driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-bike-light\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = "Add to cart";
        actualText = driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-bike-light\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println(" 'Remove' changed as 'Add to cart' ");
        } else {
            System.out.println("  'Remove' changed as 'Add to cart' failed  ");
        }
        System.out.println("......Card two verification End......");


        //verify the card three
        System.out.println(".......Card three verification start.......");
        expectedHeading = " Sauce Labs Bolt T-Shirt";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"item_1_title_link\"]/div")).getText();
        expectedInfo = "Get your testing superhero on with the Sauce Labs bolt T-shirt. From American Apparel, 100% ringspun combed cotton, heather gray with red bolt. ";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[3]/div[2]/div[1]/div")).getText();
        expectedPrice = "$15.99 ";
        actualPrice = driver.findElement(By.xpath(" //*[@id=\"inventory_container\"]/div/div[3]/div[2]/div[2]/div")).getText();
        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("Card three information is complete  ");
        } else {
            System.out.println("Card three information is not completed");
        }

        //verify if the' Add to cart button' becomes as 'remove' when clicked
        //click the Add to cart button
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-bolt-t-shirt\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = "Remove";
        actualText = driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-bolt-t-shirt\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("'Add to cart' changed as 'remove' ");
        } else {
            System.out.println("'Add to cart' became as 'remove' failed ");
        }

        //verify if the 'remove' button becomes as 'Add to cart'  when clicked
        //click the 'remove' button
        driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-bolt-t-shirt\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Add to cart";
        actualText = driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-bolt-t-shirt\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println(" 'Remove' changed as 'Add to cart' ");
        } else {
            System.out.println("  'Remove' changed as 'Add to cart' failed  ");
        }
        System.out.println("......Card three verification End......");


        //verify the card four
        System.out.println(".......Card four verification start.......");
        expectedHeading = " Sauce Labs Fleece Jacket";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"item_5_title_link\"]/div")).getText();
        expectedInfo = "  It's not every day that you come across a midweight quarter-zip fleece jacket capable of handling everything from a relaxing day outdoors to a busy day at the office.\n ";
        actualInfo = driver.findElement(By.xpath(" //*[@id=\"inventory_container\"]/div/div[4]/div[2]/div[1]/div")).getText();
        expectedPrice = "$49.99 ";
        actualPrice = driver.findElement(By.xpath("  //*[@id=\"inventory_container\"]/div/div[4]/div[2]/div[2]/div")).getText();
        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("Card four information is complete  ");
        } else {
            System.out.println("Card four information is not completed");
        }

        //verify if the' Add to cart button' becomes as 'remove' when clicked
        //click the Add to cart button
        driver.findElement(By.xpath(" //*[@id=\"add-to-cart-sauce-labs-fleece-jacket\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Remove";
        actualText = driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-fleece-jacket\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("'Add to cart' changed as 'remove' ");
        } else {
            System.out.println("'Add to cart' became as 'remove' failed ");
        }

        //verify if the 'remove' button becomes as 'Add to cart'  when clicked
        //click the 'remove' button
        driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-fleece-jacket\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = "  Add to cart";
        actualText = driver.findElement(By.xpath(" //*[@id=\"add-to-cart-sauce-labs-fleece-jacket\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println(" 'Remove' changed as 'Add to cart' ");
        } else {
            System.out.println("  'Remove' changed as 'Add to cart' failed  ");
        }
        System.out.println("......Card four verification End......");


        //verify the card five
        System.out.println(".......Card five verification start.......");
        expectedHeading = "Sauce Labs Onesie";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"item_2_title_link\"]/div")).getText();
        expectedInfo = "Rib snap infant onesie for the junior automation engineer in development. Reinforced 3-snap bottom closure, two-needle hemmed sleeved and bottom won't unravel. ";
        actualInfo = driver.findElement(By.xpath(" //*[@id=\"inventory_container\"]/div/div[5]/div[2]/div[1]/div")).getText();
        expectedPrice = "$7.99 ";
        actualPrice = driver.findElement(By.xpath(" //*[@id=\"inventory_container\"]/div/div[5]/div[2]/div[2]/div")).getText();
        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("Card five information is complete  ");
        } else {
            System.out.println("Card five information is not completed");
        }

        //verify if the' Add to cart button' becomes as 'remove' when clicked
        //click the Add to cart button
        driver.findElement(By.xpath("  //*[@id=\"add-to-cart-sauce-labs-onesie\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = "Remove";
        actualText = driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-onesie\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("'Add to cart' changed as 'remove' ");
        } else {
            System.out.println("'Add to cart' became as 'remove' failed ");
        }

        //verify if the 'remove' button becomes as 'Add to cart'  when clicked
        //click the 'remove' button
        driver.findElement(By.xpath(" //*[@id=\"remove-sauce-labs-onesie\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Add to cart";
        actualText = driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-onesie\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println(" 'Remove' changed as 'Add to cart' ");
        } else {
            System.out.println("  'Remove' changed as 'Add to cart' failed  ");
        }
        System.out.println("......Card five verification End......");


        //verify the card six
        System.out.println(".......Card six verification start.......");
        expectedHeading = " Test.allTheThings() T-Shirt (Red)";
        actualHeading = driver.findElement(By.xpath(" //*[@id=\"item_3_title_link\"]/div")).getText();
        expectedInfo = " This classic Sauce Labs t-shirt is perfect to wear when cozying up to your keyboard to automate a few tests. Super-soft and comfy ringspun combed cotton.";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[6]/div[2]/div[1]/div")).getText();
        expectedPrice = "$15.99 ";
        actualPrice = driver.findElement(By.xpath(" //*[@id=\"inventory_container\"]/div/div[6]/div[2]/div[2]/div")).getText();
        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("Card six information is complete  ");
        } else {
            System.out.println("Card six information is not completed");
        }

        //verify if the' Add to cart button' becomes as 'remove' when clicked
        //click the Add to cart button
        driver.findElement(By.xpath(" //*[@id=\"add-to-cart-test.allthethings()-t-shirt-(red)\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Remove";
        actualText = driver.findElement(By.xpath(" //*[@id=\"remove-test.allthethings()-t-shirt-(red)\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("'Add to cart' changed as 'remove' ");
        } else {
            System.out.println("'Add to cart' became as 'remove' failed ");
        }

        //verify if the 'remove' button becomes as 'Add to cart'  when clicked
        //click the 'remove' button
        driver.findElement(By.xpath("//*[@id=\"remove-test.allthethings()-t-shirt-(red)\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        expectedText = " Add to cart";
        actualText = driver.findElement(By.xpath("//*[@id=\"add-to-cart-test.allthethings()-t-shirt-(red)\"]")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println(" 'Remove' changed as 'Add to cart' ");
        } else {
            System.out.println("  'Remove' changed as 'Add to cart' failed  ");
        }
        System.out.println("......Card six verification End......");
    }

    public void YourInformationPage() throws InterruptedException {
        //Your information page loading validation-Tc 10
        YourCartCheckoutBtnClick();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        //verify if the 'Your information' page loaded successfully
        expectedHeading = "Checkout: Your Information";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (expectedHeading.equals(actualHeading)) {
            System.out.println("Successful click on Your information page ");
        } else {
            System.out.println("Unsuccessful click on Your information page");
        }
        //Sending all information and checking 'Overview' page (Happy path)-Tc 11

        //Identify the first name text box and send value
        driver.findElement(By.name("firstName")).sendKeys("Nike");
        //Identify the last name text box and send value
        driver.findElement(By.name(" lastName")).sendKeys("Fernando");
        //Identify the postal code text box and send value
        driver.findElement(By.name(" postalCode")).sendKeys("10300");
        //Identify the continue button and click
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        //verify if 'Overview page loads
        expectedHeading = "Checkout: Overview";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        if (expectedHeading.equals(actualHeading)) {
            System.out.println("Successful click on overview page");
        } else {
            System.out.println("Unsuccessful click on overview page");
        }
        // Sending only first name -Negative test case 01-Tc12
        //Identify the first name text box and send value
        driver.findElement(By.name("firstName")).sendKeys("Nike");
        //Identify the continue button and click
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        //verify if the error message displaying
        expectedText = "Error: Last Name is required";
        actualText = driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("Error message successfully displayed");
        } else {
            System.out.println("Error message not displayed");
        }
        // Sending only first name and last name  -Negative test case 02-Tc 13
        //Identify the first name text box and send value
        driver.findElement(By.name("firstName")).sendKeys("Nike");
        //Identify the last name text box and send value
        driver.findElement(By.name(" lastName")).sendKeys("Fernando");
        //Identify the continue button and click
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        //verify if the error message displaying
        expectedText = " Error: Postal Code is required  ";
        actualText = driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("Error message successfully displayed");
        } else {
            System.out.println("Error message not displayed");
        }
        // Sending only last name and postal code  -Negative test case 03-Tc 14
        //Identify the last name text box and send value
        driver.findElement(By.name(" lastName")).sendKeys("Fernando");
        //Identify the postal code text box and send value
        driver.findElement(By.name(" postalCode")).sendKeys("10300");
        //Identify the continue button and click
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        //wait for 3 seconds til the page loads
        Thread.sleep(3000);
        //verify if the error message displaying
        expectedText = " Error: First Name is required";
        actualText = driver.findElement(By.xpath(" //*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
        if (expectedText.equals(actualText)) {
            System.out.println("Error message successfully displayed");
        } else {
            System.out.println("Error message not displayed");
        }
    }

    public void OverviewPage() throws InterruptedException {
        //Verify Overview page loading-Tc 15
        //click the 'Your information ' page continue button
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
        expectedHeading = "Checkout: Overview ";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span ")).getText();
        if (expectedHeading.equals(actualHeading)) {
            System.out.println("Successful click on Products page");
        } else {
            System.out.println(("Unsuccessful click on Products page "));
        }
        //Verify the page information-Tc 16
        expectedQty = "1";
        actualQty = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[1]")).getText();
        expectedHeading = "Sauce Labs Backpack";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
        expectedInfo = "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[2]/div[1]")).getText();
        expectedItemTotal = "$29.99";
        actualItemTotal = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[2]/div[2]/div")).getText();

        if(expectedQty.equals(actualQty) && expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedPrice.equals(actualPrice)) {
            System.out.println("successful information validation");
        } else {
            System.out.println("successful information validation");
        }
        //Verify Payment information-Tc 17
        expectedHeading = "Payment Information:";
        actualHeading = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[1]")).getText();
        expectedInfo = "SauceCard #31337";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[2]")).getText();
        expectedText = "Shipping Information:";
        actualText = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[3]")).getText();
        expectedQty = "Free Pony Express Delivery!";
        actualQty = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[4]")).getText();
        expectedPrice = "Price Total";
        actualPrice = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[5]")).getText();

        if (expectedHeading.equals(actualHeading) && expectedInfo.equals(actualInfo) && expectedText.equals(actualText) && expectedQty.equals(actualQty) && expectedPrice.equals(actualPrice)) {
            System.out.println("Payment information validated successfully");
        } else {
            System.out.println("Unsuccessful Payment information validation");
        }

        //verify Price Total-Tc 18
        double itemTotal = 0, total;
        double tax = 2.40;

        total = itemTotal + tax;

        System.out.println(" Item total:" + expectedItemTotal);
        System.out.println(" Tax: $" + tax);
        System.out.println(" Total: $" + total);

        expectedText = "Item total:";
        actualText = actualItemTotal;
        expectedInfo = "Tax: $2.40";
        actualInfo = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[7]")).getText();
        expectedPrice = "Total: $32.39";
        actualPrice = String.valueOf(total);

        //verify the 'Finish ' button in overview button

        //click the 'Finish' button-Tc 19
        driver.findElement(By.xpath("//*[@id=\"finish\"]")).click();
        //wait for 3 seconds till the page loads
        Thread.sleep(3000);
        //verify if the 'Complete' page loading successfully
        expectedHeading="Checkout: Complete!";
        actualHeading=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();

        if (expectedHeading.equals(actualHeading)) {
            System.out.println("Complete page loaded successfully ");
        }
        else {
            System.out.println(" Unsuccessful Complete page loading  ");
        }
        //verify the 'Complete ' page information   -Tc20
        expectedHeading="Thank you for your order!";
        actualHeading=driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")).getText();
        expectedInfo="Your order has been dispatched, and will arrive just as fast as the pony can get there!";
        actualInfo=driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/div")).getText();

        if (expectedHeading.equals(actualHeading)&&expectedInfo.equals(actualInfo)) {
            System.out.println("Successful validation on 'Complete' page information");
        }
        else {
            System.out.println("Unsuccessful validation on 'Complete' page information");
        }

        //verify if the 'Product 'page loads when 'Back Home  ' button clicked -Tc 21
        //click the 'Back Home' button
        driver.findElement(By.xpath("//*[@id=\"back-to-products\"]")).click();
        //  wait for 3 seconds till the page loads
        Thread.sleep(3000);
        //verify if the 'Products ' page loading successfully
        expectedHeading="Products ";
        actualHeading=driver.findElement(By.xpath( "//*[@id=\"header_container\"]/div[2]/span")).getText();

        if (expectedHeading.equals(actualHeading)) {
            System.out.println(" Products page loaded successfully ");
        }
        else {
            System.out.println(" Unsuccessful Products page loading  ");
        }
    }





























        }








































