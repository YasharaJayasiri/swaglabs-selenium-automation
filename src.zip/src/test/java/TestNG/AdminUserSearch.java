package TestNG;

import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;


import static java.lang.Thread.sleep;

public class AdminUserSearch {
    //global variable section
    String BaseURL="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
    WebDriver driver;
    String actualText;
    String expectedText;
    Boolean status;
    //Before test section
    @BeforeTest
    public void BeforeTestMethod(){
        driver=new ChromeDriver();
        driver.manage().window().maximize();
    }
    //Test case section
    //After test section
    public void AfterTestMethod() throws InterruptedException {
        Thread.sleep(5000);
        driver.quit();
    }

    //Supportive Method Section
    public  void userLogin() throws InterruptedException {
        //calling the OrangeHRM Login Page
        driver.get(BaseURL);
        sleep(3000);
        //identify the username text box and send value
        driver.findElement(By.name("username")).sendKeys("Admin");
        //identify the password text box and send value
        driver.findElement(By.name("password")).sendKeys("admin123");
        //identify the login button and click
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
        sleep(3000);

    }
    public void adminClick() throws InterruptedException {
        //click Admin new item
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a")).click();
        //wait for 3 seconds till the page load
        sleep(3000);
        //verify if the Admin menu is clicked successfully
        expectedText="System Users";
        actualText=driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[1]/div[1]/h5")).getText();
        if(expectedText.equals(actualText))
        {
            System.out.println("User clicked the admin sub menu ");
        }
        else {
            System.out.println("Unsuccessful click on admin sub menu");
        }
    }
    public  void resetButtonClick() throws InterruptedException {
        //click the reset button
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[1]")).click();
        //wait for 3 seconds till the page loads
        sleep(3000);
    }
    public void userRoleDownFilterSection() throws InterruptedException {
        //click the drop down arrow under user role
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[2]/div/div[2]/div/div/div[1]")).click();
        //wait for 1 second till the drop down loads
        sleep(1000);
        //select the admin option
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[2]/div/div[2]/div/div/div[2]")).click();
        //wait for 1 second till admin option is selected
        sleep(1000);
    }
    public void searchButtonClick() throws InterruptedException {
        //click the search button
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[2]")).click();
        //wait for 5 seconds till the page loads
        Thread .sleep(5000);
    }
    public  void employeeNameEnter() throws InterruptedException {
        //enter employee name
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[3]/div/div[2]/div/div/input")).sendKeys(" Ashwaq Taha Hussein  ");

        //wait for 2 seconds till the dropdown loads
        Thread.sleep(2000);
        //select the name suggestion
        driver.findElement(By.xpath("*[@id=\\\"app\\\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[3]/div/div[2]/div/div[2]/div")).click();
        //wait for 2 seconds till suggested name is selected
        Thread.sleep(2000);
    }
    public  void statusDropDownFilterSelection() throws InterruptedException {
        //click the drop down loads
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[4]/div/div[2]/div/div/div[1]")).click();
        //wait for 1 second till the drop down loads
        Thread.sleep(1000);
        //select the enabled option
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[4]/div/div[2]/div/div/div[2]")).click();
        //wait for 1 second till enabled option is selected
        Thread.sleep(1000);
    }


















}
